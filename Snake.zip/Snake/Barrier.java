/**
 * @author Sergey Kuznetsov
 * Innopolis University
 * Summer School 2015
 */

package Snake;

import java.awt.Color;

public class Barrier extends Dot {
	
	public Barrier(int posX, int posY) {
		super(posX, posY);
		color = Color.ORANGE;
		// TODO Auto-generated constructor stub
	}
	
}
