/**
 * @author Sergey Kuznetsov
 * Innopolis University
 * Summer School 2015
 */

package Snake;

import java.awt.Color;

// The sweatest class =) 
public class BomBom extends Dot{

	public BomBom(int posX, int posY) {
		super(posX, posY);
		color = Color.CYAN;
		// TODO Auto-generated constructor stub
	}
}
