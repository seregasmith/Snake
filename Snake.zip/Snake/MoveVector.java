/**
 * @author Sergey Kuznetsov
 * Innopolis University
 * Summer School 2015
 */

package Snake;

public enum MoveVector {
	UP,DOWN,LEFT,RIGHT
}
